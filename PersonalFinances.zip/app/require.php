<?php
require_once 'libraries/Core.php';
require_once 'libraries/Controller.php';
require_once 'libraries/BusinessComponent.php';
require_once 'config/config.php';

$init = new Core();