<?php

define('DB_HOST', 'localhost');
define('DB_USERNAME', 'root');
define('DB_PASSWORD', '');
define('DB_NAME', 'financien');

define('APP_ROOT', dirname(dirname(__FILE__)));
define('URL_ROOT', 'http://localhost/financien');

define('SITE_NAME', "Financien");
define('LOGO', URL_ROOT . "/images/logo.PNG");